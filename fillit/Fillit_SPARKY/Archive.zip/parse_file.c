/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_file.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fpolyans <fpolyans@42.us.org>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/10 03:09:57 by fpolyans          #+#    #+#             */
/*   Updated: 2017/12/01 00:35:15 by fpolyans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

char	*parse_file(int fd)
{
	char	char_buffer[1];
	char	*full_tet_string;

	full_tet_string = (char*)malloc(TET_SIZE * MAX_TETS);
	while (read(fd, char_buffer, 1))
	{
		ft_strcat(full_tet_string, &char_buffer[0]);
	}
	return (full_tet_string);
}
