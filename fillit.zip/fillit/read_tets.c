/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_tets.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fpolyans <fpolyans@42.us.org>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/10 03:09:57 by fpolyans          #+#    #+#             */
/*   Updated: 2017/11/10 08:17:58 by fpolyans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

void	parse_tets(int fd)
{
	int buf_loc;
	char	*buffer;

	buf_loc = 0;
	buffer = (char*)malloc(3);
	while ((buf_loc = read(fd, buffer, 1)))
	{
		buffer[buf_loc] = '\0';
		
	}
}
